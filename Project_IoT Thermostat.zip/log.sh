#!/bin/bash

# SSH into the AWS EC2 instance and run the Flask server
ssh -i "myawskey.pem" ubuntu@ec2-3-136-85-201.us-east-2.compute.amazonaws.com << EOF

# Navigate to the Flask application directory
cd flask_app

# Set up Python virtual environment
python3 -m venv myenv
source myenv/bin/activate
tail -f server.log
EOF
