# ECE531 Intro Of Internet of Things
# Summer 2024

# IoT Smart Thermostat Project

## Project Description
This project implements an IoT smart thermostat system that communicates with a Flask server. 
The IoT client reads temperature and heater status, then sends this data to the server periodically.
When daemons are ran, the thermostat will

	-- Read temperature from a thermocouple
	-- Show the status of the thermostat
	-- Uses HTTPS to communicate with cloud
	
Server URL: http://ec2-3-136-85-201.us-east-2.compute.amazonaws.com:5001/


## Setup Instructions
  **Extract the Archive**:
   tar -xzvf project.tgz
   cd project
   
## Startup on boot(Use provided Credentials): 
   1. ./project.sh        
	     
## See HTTPS Communication with server ( At AWS EC2 )
   2. ./log.sh
   
 
